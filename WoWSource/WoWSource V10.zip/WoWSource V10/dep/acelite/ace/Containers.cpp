// $Id: Containers.cpp 91286 2010-08-05 09:04:31Z johnnyw $

#include "ace/Containers.h"

#if !defined (__ACE_INLINE__)
#include "ace/Containers.inl"
#endif /* __ACE_INLINE__ */

