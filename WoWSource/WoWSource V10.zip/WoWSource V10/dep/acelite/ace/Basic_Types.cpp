// $Id: Basic_Types.cpp 95763 2012-05-16 06:43:51Z johnnyw $

#include "ace/Basic_Types.h"
